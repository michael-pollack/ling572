import argparse
import numpy as np

arg_parser = argparse.ArgumentParser()
arg_parser.add_argument('--test_data', type=str)
arg_parser.add_argument('--model_file', type=str)
arg_parser.add_argument('--sys_output', type=str)

args = arg_parser.parse_args()

class Decoder:
    def __init__(self, model_file):
        self.sv_coef = None
        self.support_vectors = None
        self.rho = None
        self.kernel_type = 'linear'
        self.gamma = 1.0  
        self.degree = 3  
        self.coef0 = 0.0  
        self.load_model(model_file)

    def run_predict(self, test_data, test_labels, sys_output):
        predictions = self.predict(test_data)
        self.print_predictions(predictions, test_labels, sys_output)

    def print_predictions(self, predictions, test_labels, sys_output):
        accuracy = []
        output = ""
        for i in range(len(predictions)):
            pred, fx = predictions[i]
            if pred == test_labels[i]:
                accuracy.append(1)
            else:
                accuracy.append(0)
            output += f"{test_labels[i]} {pred} {fx}\n"
        total_acc = sum(accuracy) / len(accuracy)
        print(f"Accuracy: {total_acc}")
        with open(sys_output, 'w') as output_file:
            output_file.write(output)
    
    def load_model(self, model_file):
        with open(model_file, 'r') as f:
            lines = f.readlines()
        
        sv_start = False
        sv_coef = [] 
        support_vectors = []
        max_feature_index = 0  

        for line in lines:
            line = line.strip()
            if line.startswith('svm_type'):
                assert line.split()[1] == 'c_svc', "Only C-SVC is supported."
            elif line.startswith('kernel_type'):
                self.kernel_type = line.split()[1]
            elif line.startswith('gamma'):
                self.gamma = float(line.split()[1])
            elif line.startswith('coef0'):
                self.coef0 = float(line.split()[1])
            elif line.startswith('degree'):
                self.degree = int(line.split()[1])
            elif line.startswith('rho'):
                self.rho = float(line.split()[1])
            elif line.startswith('SV'):
                sv_start = True
                continue  
            
            if sv_start:
                parts = line.split()
                sv_coef.append(float(parts[0]))  

                feature_dict = {}
                for item in parts[1:]:
                    index, value = item.split(":")
                    index = int(index)
                    value = float(value)
                    feature_dict[index] = value
                    max_feature_index = max(max_feature_index, index)

                support_vectors.append(feature_dict)

        num_sv = len(support_vectors)
        dense_support_vectors = np.zeros((num_sv, max_feature_index + 1))

        for i, feature_dict in enumerate(support_vectors):
            for index, value in feature_dict.items():
                dense_support_vectors[i, index] = value

        self.sv_coef = np.array(sv_coef, dtype=float) 
        self.support_vectors = dense_support_vectors  
        self.num_features = max_feature_index + 1  



    def kernel_function(self, x, y):
        if self.kernel_type == 'linear':
            return np.dot(x, y)
        elif self.kernel_type == 'rbf':
            return np.exp(-self.gamma * np.linalg.norm(x - y) ** 2)
        elif self.kernel_type == 'polynomial':
            return (self.gamma * np.dot(x, y) + self.coef0) ** self.degree
        elif self.kernel_type == 'sigmoid':
            return np.tanh(self.gamma * np.dot(x, y) + self.coef0)
        else:
            raise ValueError("Unsupported kernel type")

    def predict(self, X):
        predictions = []
        for x in X:
            decision_value = sum(self.sv_coef[i] * self.kernel_function(self.support_vectors[i], x) for i in range(len(self.sv_coef))) - self.rho
            prediction = 0 if decision_value >= 0 else 1
            predictions.append((prediction, decision_value))
        return predictions
        
def load_libsvm_test_data(file_path: str, expected_features: int):
    with open(file_path, "r") as f:
        lines = f.readlines()
    
    instances = []
    labels = []
    
    for line in lines:
        parts = line.strip().split()
        labels.append(int(parts[0])) 
        
        features = {}
        for item in parts[1:]:
            index, value = item.split(":")
            index = int(index)
            value = float(value)
            features[index] = value
        
        instances.append(features)

    num_samples = len(instances)
    dense_data = np.zeros((num_samples, expected_features))

    for i, features in enumerate(instances):
        for index, value in features.items():
            if index < expected_features: 
                dense_data[i, index] = value

    return dense_data, labels


def main():
    decoder = Decoder(args.model_file)
    test_data, test_labels = load_libsvm_test_data(args.test_data, decoder.num_features)
    decoder.run_predict(test_data, test_labels, args.sys_output)

    
if __name__ == "__main__":
    result = main()
